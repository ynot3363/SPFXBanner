import { BaseDialog, IDialogConfiguration } from '@microsoft/sp-dialog';
export default class CustomDialog extends BaseDialog {
    itemUrlFromExtension: string;
    otherParam: string;
    paramFromDialog: string;
    render(): void;
    private _setButtonEventHandlers();
    getConfig(): IDialogConfiguration;
    protected onAfterClose(): void;
}
