declare const styles: {
    app: string;
    header: string;
    footer: string;
    dynamicClass: string;
    bannas: string;
    apples: string;
    grapes: string;
    oranges: string;
    bottomBanner: string;
};
export default styles;
