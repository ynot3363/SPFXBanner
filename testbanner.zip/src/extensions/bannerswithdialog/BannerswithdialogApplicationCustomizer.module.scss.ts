/* tslint:disable */
require('./BannerswithdialogApplicationCustomizer.module.css');
const styles = {
  app: 'app_22c4a81f',
  header: 'header_22c4a81f',
  footer: 'footer_22c4a81f',
  dynamicClass: 'dynamicClass_22c4a81f',
  bannas: 'bannas_22c4a81f',
  apples: 'apples_22c4a81f',
  grapes: 'grapes_22c4a81f',
  oranges: 'oranges_22c4a81f',
  bottomBanner: 'bottomBanner_22c4a81f',
};

export default styles;
/* tslint:enable */