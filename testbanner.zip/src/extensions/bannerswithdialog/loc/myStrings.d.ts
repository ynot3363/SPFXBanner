declare interface IBannerswithdialogApplicationCustomizerStrings {
  Title: string;
}

declare module 'BannerswithdialogApplicationCustomizerStrings' {
  const strings: IBannerswithdialogApplicationCustomizerStrings;
  export = strings;
}
