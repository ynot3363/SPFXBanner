define([], function() {
  return {
    "Title": "BannerswithdialogApplicationCustomizer"
  }
});